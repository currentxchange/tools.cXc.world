# gift.star

Frontend for the gift.star project, powered by [SvelteKit](https://kit.svelte.dev/).
